#nesting
#(5)	(1)+(1+2)+(1+2+3)+(1+2+3+4)…………..up to n terms**

# i =1 x = 1 2 3 4
# i =2 x = 1 2 3 4
# i =3 x = 1 2 3 4
# i =4 x = 1 2 3 4


for i in range(1,5):
     for x in range(1,5):
          print(x,end='')
     print()
          



for i in range(1,5):
     for x in range(1,i+1):
          print(x,end='')
     print()     
     


for i in range(1,5):
     print('(',end='')
     for x in range(1,i+1):
          if x<i:
               print(x,end='+')
          else:
               print(x,end='')
     print(')+',end='') 
     
