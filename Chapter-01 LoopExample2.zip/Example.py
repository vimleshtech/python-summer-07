a =11  #a is variabel and 11 is data or value
b =55 

c = a+b  #expression 
print(c)  #show result


#exmple 2
n1 = input('enter data :')
n2 = input('enter data :')

print(type(n1))
print(type(n2))

#type casting or conversion
n1 =int(n1)
n2 =int(n2)


print(type(n1))
print(type(n2))


n = n1+n2
print(n)

##or
n1 = int(input('enter data :')) #read and convert to int
n2 = int(input('enter data :'))
n =n1+n2
print('sum of two numbers ',end='') #don't change line , -
print(n)

print('sum of two numbers ', n)

print('sum of\n two \n numbers ', n)


print('sum of a {} and b {} is  {}'.format(n1,n2,n))
print('sum of a ',n1,' and b ',n2,' is  ',n)
print('sum of a {1} and b {0} is  {2}'.format(n1,n2,n))





























