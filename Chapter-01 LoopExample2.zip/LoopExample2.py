#wap to get sum or all even and odd numebers between 1 to 100
se =0
so = 0

for x in range(1,101):# from 1 to 100
     if x%2 ==0:
          se =se+x
     else:
          so = so+x

print('sum of all even no ',se)
print('sum of all odd no ',so)

     
#wap to print table of given no
n = int(input('enter no :'))
for i in range(1,11):
     print(n*i)
     

#
x = 1
inc =0
for i in range(1,10):
     print(x,end='\t')
     x = x+4+inc
     inc = inc+2

x=2
for i in range(1,10):
     print(x, end='\t')
     x=x*2

n=1
for i in range (1,15):
     print(n, end='\t')
     n=n+3


n=1
ne=0
no=0
for i in range(1,15):
     n=n+3
     if n%2 ==0:
          print('-',n, end='\t')
     else:
          print(n, end='\t')









     
     
     
