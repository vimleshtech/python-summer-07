#loop # while


i =1 #init
while i<10: #condition 
     print(i,end='\t')
     i =i+1  #increment / decrement



     

#print in reverse number
i =10
while i>0:
     print(i)
     i=i-1


n =100
#for loop
for x in range(1,n+1):
     print(x)
     
#in reverse
for i in range(10,0,-1):
     print(i)
     
